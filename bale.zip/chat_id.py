from bale import Bot, Update, Message, EventType , InlineKeyboard , Components , CallbackQuery 
from main import when_receive_message , client

@client.listen(EventType.CALLBACK)
async def when_receive_callback(callback: CallbackQuery):    
    if callback.data == "chatidd":
        await callback.message.reply(text=f" * chat id : {callback.user.chat_id} *")





