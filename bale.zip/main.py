from bale import Bot, Update, Message, EventType , InlineKeyboard , Components , CallbackQuery 
import os
from colorama import Fore
from time import sleep
client = Bot(token="164623604:jhayZ69cccgE9XKeRuH7WGTQXzPVUaPDLNkwvbDh")
os.system("cls")
import random
@client.listen(EventType.READY)
async def when_bot_is_ready():
    print( Fore.BLUE, client.user, "is Ready!" , Fore.RESET )

@client.listen(EventType.UPDATE)
async def when_receive_update(update: Update):
    
    print(update.update_id, update.type)




@client.listen(EventType.MESSAGE)


async def when_receive_message(message: Message):
    if message.chat.type.is_private_chat():
        try :                                     
                id = message.author.chat_id
                x = await client.get_chat_member(5534276296 , id)                          
                if message.content == "/start" :

                        
                    await message.reply(text=f"* Hi! {message.author.first_name} \n welcome to my bot \n Your username : {message.author.username}  \n Your chat id : {message.author.user_id} \n please join my channel \n @proxyfree * ")
                        
                if message.content == "13851385" :
                                        await message.reply(text=f"* hi {message.author.first_name} \n welcome to manager panel please choose button *"
                                                , components = Components(inline_keyboards=[[
                                                    InlineKeyboard("  ممبر زن گروه" , callback_data="addmember") ,
                                                    InlineKeyboard("  گرفتن چت آیدی" , callback_data="chatidd") ,
                                                    InlineKeyboard(" اس ام اس بمبر " , callback_data="bomber") , 
                                                    InlineKeyboard("مدیریت گروه" , callback_data="mng") , 
                                                    InlineKeyboard(" سفارش فالور و ممبر" , callback_data="buymember") , 
                                                    InlineKeyboard("ارتباط با پشتیبانی" , callback_data="support")
                                                    
                                                ]]))
                                        
        except :
               w = message.chat.chat_id
               await message.reply(text=f"""* 
🌹 کاربر {message.author.first_name} -  {'@'+message.author.username}

• برای ارسال پیام باید عضو کانال زیر باشید 🌱

• لطفا با استفاده از دکمه زیر در کانال عضو شوید 


🤖این پیام به صورت خودکار پاک خواهد شد 

[اگر کار نکرد اینجا را کلیک کنید](ble.ir/join/YzBhMjEyM2)*""" ,
 components = Components(inline_keyboards=[[InlineKeyboard("عضویـت در کانـال" , callback_data="joins" , url="https://ble.ir/join/YzBhMjEyM2")]]))
                          

    


                
                

    
         
                

                

                                

                                
                            
                            
                    
                            
            

