from bale import Bot, Update, Message, EventType , InlineKeyboard , Components , CallbackQuery 
from main import when_receive_message , client
from time import sleep
@client.listen(EventType.CALLBACK)
async def when_receive_callback(callback: CallbackQuery):    
    if callback.data == "mng":
        await callback.message.reply(text=f"*برای فعالسازی بات در گروه خود،ابتدا ربات را در گروه عضو و مدیر کرده و سپس کلمه run را در گروه ارسال کنید*")

@client.listen(EventType.MESSAGE)
async def force(message :Message):
    if message.chat.type.is_group_chat():
        try :
            id = message.author.chat_id
            gp = message.chat.chat_id

            x = await client.get_chat_member(5534276296 , id) 

        except :
            msgg = message.message_id
            await client.delete_message(chat_id= gp ,  message_id= msgg)
            a = await message.reply(text=f"""* 
🌹 کاربر {message.author.first_name} -  {'@'+message.author.username}

• برای ارسال پیام باید عضو کانال زیر باشید 🌱

• لطفا با استفاده از دکمه زیر در کانال عضو شوید 


🤖این پیام به صورت خودکار پاک خواهد شد 

[اگر کار نکرد اینجا را کلیک کنید](ble.ir/join/YzBhMjEyM2)*""" ,
 components = Components(inline_keyboards=[[InlineKeyboard("عضویـت در کانـال" , callback_data="join", url="https://ble.ir/join/YzBhMjEyM2")]]))
                                                
                                                
            sleep(30)
            await client.delete_message(chat_id= gp , message_id= a.message_id) 

       
            