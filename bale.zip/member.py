from bale import Bot, Update, Message, EventType , InlineKeyboard , Components , CallbackQuery 
from main import when_receive_message , client

@client.listen(EventType.CALLBACK)
async def when_receive_callback(callback: CallbackQuery):    
    if callback.data == "addmember":
        await callback.message.reply(text=f"* این امکان به زودی فراهم می شود*")

