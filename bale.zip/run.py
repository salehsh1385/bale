from main import *
from chat_id import *
from bomb import *
from support import *
from gpt import *
from member import *


client.run()